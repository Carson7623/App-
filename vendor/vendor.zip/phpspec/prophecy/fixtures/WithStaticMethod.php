<?php

namespace Fixtures\Prophecy;

class WithStaticMethod
{
    public static function innerDetail()
    {
    }
}
