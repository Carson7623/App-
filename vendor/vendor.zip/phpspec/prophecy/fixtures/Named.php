<?php

namespace Fixtures\Prophecy;

interface Named
{
    public function getName();
}
