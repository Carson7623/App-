<?php
if ($neverHappens) {
    print '*';
}
